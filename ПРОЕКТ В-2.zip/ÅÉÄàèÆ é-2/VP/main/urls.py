from django.urls import path
from . import views
from django.contrib.auth import views as authViews

urlpatterns = [
    path('report', views.index, name='report'),
    path('profile', views.profile, name='profile'),
    path('main', views.MainView.as_view(), name='main'),
    path('login', views.LoginFormView.as_view(), name='login'),
    path('registration', views.RegisterFormView.as_view()),
    path('exit', authViews.LogoutView.as_view(next_page='main'))
]
