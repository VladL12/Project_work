from django.shortcuts import render
import pandas as pd
from django.views.decorators.csrf import csrf_protect
import plotly.express as px
import plotly.graph_objects as go
from rest_framework.decorators import api_view
from django.views.generic import TemplateView
from django.views.generic.edit import FormView
from django.shortcuts import redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login

folder = "C:/Users/Григорий/Desktop/Поднять сервер/СЕРВЕР/НА ДЭШ/"
df_count = pd.ExcelFile(folder + "_out_данные.xlsx").parse(0, header=None)
df_now = pd.ExcelFile(folder + "_out_данные.xlsx").parse(1, header=None)
df_declared = pd.ExcelFile(folder + "_out_данные.xlsx").parse(2, header=None)
df_paid = pd.ExcelFile(folder + "_out_данные.xlsx").parse(3, header=None)


@csrf_protect
@api_view(['GET', 'POST'])
def index(request):

    if not request.user.is_authenticated:
        return redirect('login')

    def b_line_part_maker(df_full, b_line):
        df_full.iloc[0] = df_full.iloc[0].fillna(method='ffill')
        df_full.columns = df_full.iloc[0]
        df_full = df_full[1:]
        df_temp = df_full[b_line]
        df_temp.columns = df_temp.iloc[0]
        df_temp = df_temp[2:]
        df_temp = pd.DataFrame(df_temp.values, columns=['Частично выпл', 'выпл',
                                                        'закрыто', 'отказ', 'открыто'])

        df_temp.index = ['2021/01', '2021/02', '2021/03', '2021/04', '2021/05', '2021/06',
                         '2021/07', '2021/08', '2021/09', '2021/10', '2021/11', '2021/12',
                         '2022/01', '2022/02', '2022/03', '2022/04', '2022/05', '2022/06',
                         '2022/07', '2022/08']
        y_labels = df_temp.columns
        for i in y_labels:
            df_temp[i] = pd.to_numeric(df_temp[i], downcast='float')
        df_temp = df_temp.fillna(0)
        return df_temp

    color_discrete_map = {'закрыто': 'red', 'выпл': 'green', 'открыто': 'gold',
                          'отказ': 'cornflowerblue', 'Частично выпл': 'cyan'}
    category_orders = {'статус': ['выпл', 'открыто', 'Частично выпл',
                                  'закрыто', 'отказ']}

    if request.method == 'POST':
        bline = request.POST.get("bline")
    else:
        bline = '01 - КАСКО'

    df_count_CMTPL = b_line_part_maker(df_count, bline)
    df_now_CMTPL = b_line_part_maker(df_now, bline)
    df_declared_CMTPL = b_line_part_maker(df_declared, bline)
    df_paid_CMTPL = b_line_part_maker(df_paid, bline)

    fig_1 = go.FigureWidget(px.bar(df_count_CMTPL, y=df_count_CMTPL.columns, title='Количество на месяц',
                                   color_discrete_map=color_discrete_map, category_orders=category_orders,
                                   text_auto='.2s'))
    fig_2 = go.FigureWidget(px.bar(df_now_CMTPL, y=df_now_CMTPL.columns, title='РЗУ на текущий месяц',
                                   color_discrete_map=color_discrete_map, category_orders=category_orders,
                                   text_auto='.2s'))
    fig_3 = go.FigureWidget(px.bar(df_declared_CMTPL, y=df_declared_CMTPL.columns, title='РЗУ на дату заявления',
                                   color_discrete_map=color_discrete_map, category_orders=category_orders,
                                   text_auto='.2s'))
    fig_4 = go.FigureWidget(px.bar(df_paid_CMTPL, y=df_paid_CMTPL.columns, title='оплачено РЗУ на текущий момент',
                                   color_discrete_map=color_discrete_map, category_orders=category_orders,
                                   text_auto='.2s'))

    graph_1 = fig_1.to_html(full_html=False)
    graph_2 = fig_2.to_html(full_html=False)
    graph_3 = fig_3.to_html(full_html=False)
    graph_4 = fig_4.to_html(full_html=False)

    return render(request, 'main/index.html', {'graph_1': graph_1, 'graph_2': graph_2,
                                               'graph_3': graph_3, 'graph_4': graph_4,
                                               'bline1': bline})


class MainView(TemplateView):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('report')
        else:
            return redirect('login')


class LoginFormView(FormView):

    form_class = AuthenticationForm
    template_name = 'main/login.html'
    success_url = 'report'

    def form_valid(self, form):
        login(self.request, form.get_user())
        return super(LoginFormView, self).form_valid(form)

    def form_invalid(self, form):
        return super(LoginFormView, self).form_invalid(form)


class RegisterFormView(FormView):
    form_class = UserCreationForm
    success_url = 'report'
    template_name = 'main/registration.html'

    def form_valid(self, form):
        form.save()
        return super(RegisterFormView, self).form_valid(form)

    def form_invalid(self, form):
        return super(RegisterFormView, self).form_invalid(form)
